Mapped
======
WoW Addon. Informations about your current Zone/Sub-Zone
