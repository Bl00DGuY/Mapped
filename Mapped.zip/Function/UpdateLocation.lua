local AceGUI = LibStub("AceGUI-3.0")
local tourist = LibStub("LibTourist-3.0");
local currentZone = GetZoneText();
local currentSubZone = GetSubZoneText();
local mapID = GetCurrentMapAreaID()
local zoneText = GetMapNameByID(mapID) or UNKNOWN;

function UpdateLocation()


end